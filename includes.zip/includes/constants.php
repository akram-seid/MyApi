<?php
define('DB_NAME','mydb');
define('DB_USER','pma');
define('DB_PASSWORD','');
define('DB_HOST','localhost');

?>