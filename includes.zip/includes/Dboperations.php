<?php
  class DbOperations{

		private $con; 

		function __construct(){

			require_once dirname(__FILE__).'/Dbconnect.php';

			$db = new Dbconnect();

			$this->con = $db->connect();

		}
        public function userLogin($table,$username, $pass){
				
            $stmt = $this->con->prepare("SELECT * FROM $table WHERE username =? AND password =? ");
            $stmt->bind_param("ss",$username,$pass);
            $stmt->execute();
            $stmt->store_result(); 
            return $stmt->num_rows > 0; 
        }
        function getIns($username){
            $stmt = "SELECT ins_id FROM instructors WHERE username = '$username'";
        $result=mysqli_query($this->con,$stmt);
    
        $row=mysqli_fetch_row($result);
        
        return $row[0]; 

        }
        function getStudent($username){
            $stmt = "SELECT stud_id FROM students WHERE username = '$username'";
        $result=mysqli_query($this->con,$stmt);
    
        $row=mysqli_fetch_row($result);
        
        return $row[0]; 

        }
    }